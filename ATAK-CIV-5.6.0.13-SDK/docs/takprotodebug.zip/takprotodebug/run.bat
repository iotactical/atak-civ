@echo off
java -classpath ./build/libs/takprotodebug.jar:protobuf-java-3.8.0.jar com.partech.takprotoparser.Parser %*
